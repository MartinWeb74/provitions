// import { Navbar, Container, Nav } from 'react-bootstrap';
import heroBook from '../assets/hero-book.png';
import previewIcon from '../assets/preview-icon.png';
import buynowIcon from '../assets/buynow-icon.png';

function HeroSection() {
  return (
    <div className="hero-section">
      <div className="hero-image">
      <img
        src={heroBook}
        width="289"
        height="386"
        className="d-inline-block align-top"
        alt="book cover"
      />
      </div>
      <div className="hero-text">
        <div className="first-line-text">Most in-demand new title:</div>
        <div className="second-line-text">The Midnight Library</div>
        <div className="third-line-text">Written and narrated by professor Matt Haig</div>
        <div className="fourth-line-text">New this month</div>
        <div className="fifth-line-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</div>
        <div className="buttons-section">
          <button className="hero-btn preview-btn">
            Preview&nbsp;
            <img
              src={previewIcon}
              width="24"
              height="24"
              className="d-inline-block align-top"
              alt="preview icon"
            />
          </button>
          <button className="hero-btn buy-now-btn">
            Buy Now&nbsp;
            <img
              src={buynowIcon}
              width="24"
              height="24"
              className="d-inline-block align-top"
              alt="preview icon"
            />
          </button>
        </div>
      </div>
    </div>
  );
}

export default HeroSection;
