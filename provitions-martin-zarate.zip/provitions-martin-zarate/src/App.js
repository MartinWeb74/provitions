import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import NavbarComponent from './Components/NavbarComponent';
import HeroSection from './Components/HeroSection';

function App() {
  return (
    <div className="main-wrapper">
      <NavbarComponent />
      <section>
        <HeroSection />
      </section>
    </div>
  );
}

export default App;
