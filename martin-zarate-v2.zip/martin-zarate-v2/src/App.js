import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import NavbarComponent from './Components/NavbarComponent';
import HeroSection from './Components/HeroSection';
import CarouselSection from './Components/CarouselSection';
import ReadingSection from './Components/ReadingSection';

function App() {
  return (
    <div className="main-wrapper">
      <NavbarComponent />
      <section>
        <HeroSection />
      </section>
      <section>
        <CarouselSection />
      </section>
      <section>
        <ReadingSection />
      </section>
    </div>
  );
}

export default App;
