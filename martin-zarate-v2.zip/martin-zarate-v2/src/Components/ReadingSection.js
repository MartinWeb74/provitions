

function ReadingSection() {

  return (<>
    <div className="reading-section">
      <div className="reading-column reading-1">
        <p>
          Coffee table books that you will never set down
        </p>
      </div>
      <div className="reading-column reading-2">
        <p>
          Stuff that you will read slower b/c it makes you laugh
        </p>
      </div>
      <div className="reading-column reading-3">
        <p>
          "Me time" with these thrilling suspense novels
        </p>
      </div>
      <div className="reading-column reading-4">
        <p>
          Childrens books reviewed by us and loved by children
        </p>
      </div>
    </div>
  </>);
}

export default ReadingSection;
