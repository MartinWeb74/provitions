
import rightArrowIcon from '../assets/right-arrow-green.png';
import exclamationIcon from '../assets/exclamation-white.png';
import articleFeature from '../assets/article-feature.png';

function ArticleSection() {
  return (
    <div className="article-section">
      <div className="article-title">Are &#8220;choose your own adventure&#8221; books making a comeback?</div>
      <div className="article-subtitle">Low-fi adventure returns to the shelves</div>
      <div className="article-feature-image">
        <img
          src={articleFeature}
          width="100%"
          height="auto"
          className="d-inline-block align-top"
          alt="feature article"
        />
      </div>
      <div className="article-paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Varius quam quisque id diam vel quam elementum pulvinar. Purus gravida quis blandit turpis. Felis eget velit aliquet sagittis id. Quis viverra nibh cras pulvinar mattis. Mattis vulputate enim nulla aliquet porttitor lacus luctus. Suspendisse interdum consectetur libero id faucibus nisl tincidunt eget.</div>
      <div className="article-paragraph">Velit scelerisque in dictum non consectetur a erat. Diam vulputate ut pharetra sit amet aliquam id diam maecenas. Amet consectetur adipiscing elit ut aliquam. Neque egestas congue quisque egestas diam. Tempus urna et pharetra pharetra massa massa. Quis varius quam quisque id diam vel. Amet venenatis urna cursus eget nunc scelerisque. Odio pellentesque diam volutpat commodo sed egestas egestas fringilla. Ac tincidunt vitae semper quis lectus nulla at. Leo vel orci porta non pulvinar.</div>
      <div className="article-paragraph">Elit eget gravida cum sociis. Lacus vestibulum sed arcu non odio euismod lacinia at quis. Arcu dictum varius duis at. Vulputate odio ut enim blandit volutpat maecenas volutpat.</div>
      <div className="article-buttons-section">
        <button className="hero-btn premium-btn">
        Start your free trial of our premium content&nbsp;
        <img
            src={rightArrowIcon}
            width="24"
            height="24"
            className="d-inline-block align-top"
            alt="preview icon"
        />
        </button>
        <button className="hero-btn buy-now-btn similar-btn">
        Similar Content&nbsp;
        <img
            src={exclamationIcon}
            width="24"
            height="24"
            className="d-inline-block align-top"
            alt="preview icon"
        />
        </button>
      </div>
    </div>
  );
}

export default ArticleSection;
