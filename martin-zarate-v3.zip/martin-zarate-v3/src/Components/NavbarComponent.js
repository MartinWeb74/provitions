import { Navbar, Container, Nav } from 'react-bootstrap';
import brandLogo from '../assets/logo-black-text.png';
import userIcon from '../assets/user-icon.png';
import searchIcon from '../assets/search-icon.png';

function NavbarComponent() {
  return (
    <Navbar expand="lg" className="navbar-custom">
      <Container>
        <Navbar.Brand href="#home">
          <img
            src={brandLogo}
            width="135"
            height="42"
            className="d-inline-block align-top"
            alt="logo"
          />
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link href="#fiction">Fiction</Nav.Link>
            <Nav.Link href="#non-fiction">Non-Fiction</Nav.Link>
            <Nav.Link href="#educational">Educational</Nav.Link>
            <Nav.Link href="#resource">Resource</Nav.Link>
            <span className="nav-spacer"></span>
            <button className="nav-btn">SHOP</button>
            <Nav.Link href="#donate">Donate</Nav.Link>
            <Nav.Link href="#login">Log In
            <img
              src={userIcon}
              width="18"
              height="18"
              className="d-inline-block nav-user-icon"
              alt="user icon"
            />
            </Nav.Link>
            <Nav.Link href="#login">
            <img
              src={searchIcon}
              width="24"
              height="24"
              className="d-inline-block"
              alt="search icon"
            />
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default NavbarComponent;
