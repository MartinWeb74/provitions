
import slide1 from '../assets/1.png';
import slide2 from '../assets/2.png';
import slide3 from '../assets/3.png';
import slide4 from '../assets/4.png';
import slide5 from '../assets/5.png';
import slide6 from '../assets/6.png';

function CarouselSection() {

  return (<>
    <div className="quote-section">
      <div className="quote-text">&#8220;It don't mean a thing if it ain't got that swing&#8221;</div>
      <div className="quote-author">Ella Fitzgerald</div>
    </div>
    <div className="slider-book-covers">
        <img
        className="slide-img"
        src={slide1}
        alt="book cover"
        />
        <img
        className="slide-img"
        src={slide2}
        alt="book cover"
        />
        <img
        className="slide-img"
        src={slide3}
        alt="book cover"
        />
        <img
        className="slide-img"
        src={slide4}
        alt="book cover"
        />
        <img
        className="slide-img"
        src={slide5}
        alt="book cover"
        />
        <img
        className="slide-img"
        src={slide6}
        alt="book cover"
        />
    </div>
  </>);
}

export default CarouselSection;
